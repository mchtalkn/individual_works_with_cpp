#include "Bank.h"


/**
 * Empty constructor
 * give the bank_name as "not_defined"
 * give nullptr for pointers
 * give 0 as _users_count
 */
Bank::Bank() {
    _bank_name = "not_defined";
    _user_count = 0;
    _users = nullptr;
}
/**
 * Constructor
 *
 *
 * @param bank_name name of this bank
 * @param users pointer to hold users of this bank
 * @param user_count number of users this bank has
*/
Bank::Bank(std::string bank_name, Account* const users, int user_count) {
    _bank_name = bank_name;
    _user_count = user_count;
    _users = new Account[user_count];
    for (int i = 0; i < user_count; i++) {
        _users[i] = users[i];
    }
}
/**
 * Destructor
 *
 * Do not forget to free the space you have created(This assignment does not use smart pointers)
 */
Bank::~Bank() {
    delete[] _users;
}
/**
 * Copy constructor(Deep copy)
 *
 * @param rhs The Bank to be copied
 */
Bank::Bank(const Bank& rhs) {
    _bank_name = rhs._bank_name;
    *this += rhs;
}
/**
 * You should deep copy the content of the second bank
 * Merge two banks
 * If both banks has a user with the same id, Transactions of these users will be merged in to the same Account
 * For example:
 * Bank1 has [1,2] id users
 * Bank2 has [2,3] id users
 *
 * Bank1 after += operator will have [1,2,3] id users
 * User with id 2 will have its transactions histories merged
 *
 * Transactions with of the users with the same id should be merged and updated
 * @param rhs Merged Bank
 * @return this Bank
 */
Bank& Bank::operator+=(const Bank& rhs) {
    for (int i = 0; i < rhs._user_count; i++)
    {
        *this += rhs._users[i];
    }
}

/**
 * Add a new account to Bank
 *
 * If the newly added user already exists in this Bank merge their Transactions
 *
 * @param new_acc new account to add to bank
 * @return this Bank
 */
Bank& Bank::operator+=(const Account& new_acc) {

    for (int i = 0; i < _user_count; i++)
    {
        if (_users[i] == new_acc) return *this;
    }
    Account* tmp = _users;
    _users = new Account[_user_count + 1];
    for (int i = 0; i < _user_count; i++)
    {
        _users[i] = tmp[i];
    }
    _users[_user_count] = new_acc;
    _user_count++;
    delete[] tmp;
    return *this;
}

/** Indexing operator overload
 *
 * Return the Account with the given id
 *
 * If there is no Account with the given id return the first element
 *
 * @param account_id id of the Account
 * @return if given id exist in the bank return the account, else return the first account
 *
 */
Account& Bank::operator[](int account_id) {
    for (int i = 0; i < _user_count; i++)
    {
        if (_users[i] == account_id) return _users[i];
    }
    return _users[0];
}

/**
 * Stream overload.
 * all the accounts will be between 01-01-2019 and 31-12-2019
 * What to stream
 * bank_name"tab"number of users who are eligible for a loan"tab"total balance of the bank
 *
 * A user is safe for a loan if and only if that user did not have any negative balance for 2 or more consecutive months
 * For example, let's say our bank named as "banana" has two users
 *
 * User A's balance for each month is as given
 *
 * January - 0
 * February - 0
 * March - 100
 * April - -20
 * May - -30
 * June - 40
 * July - 60
 * August - 0
 * September - 0
 * October - 0
 * November - 0
 * December - 0
 *
 * This user is not eligible because in April and May his/her balance was negative(consecutive)
 * You still have to add 150 to the total balance of the bank
 * User B's balance for each month is as given
 *
 * January - 0
 * February - 0
 * March - 100
 * April - -20
 * May - 40
 * June - -30
 * July - 60
 * August - 0
 * September - 0
 * October - 0
 * November - 0
 * December - 0
 *
 * This user is eligible because negative balances were not consecutive
 * You will also add 150 to the total balance of the bank
 *
 * your output will be as
 * banana   1   300
 */
bool check_eligibility(Account account) {
    tm tmp_start, tmp_end;
    tmp_end.tm_sec = 0;
    tmp_end.tm_min = 0;
    tmp_end.tm_hour = 0;
    tmp_end.tm_mday = 0;
    tmp_end.tm_mon = 0;
    tmp_end.tm_year = 119;
    tmp_end.tm_wday = 0;
    tmp_end.tm_yday = 0;
    tmp_end.tm_isdst = 0;
    tmp_start = tmp_end;
    tmp_end.tm_mon = 2;
    //std::cout << "account" << account;
    for (int i = 0; i < 10; i++)
    {
        tmp_start.tm_mon++;
        tmp_end.tm_mon++;
      //  std::cout << "balance between" << tmp_start.tm_mon << "-" << tmp_end.tm_mon <<"=="<< account.balance(mktime(&tmp_start) - 1, mktime(&tmp_end)) << std::endl << std::endl;
        if (account.balance(mktime(&tmp_start) - 1, mktime(&tmp_end)) < 0) return false;
    }
    return true;
}
std::ostream& operator<<(std::ostream& os, const Bank& bank) {
    int balance = 0;
    int nof_eligible = 0;
    for (int i = 0; i < bank._user_count; i++) {
        balance += bank._users[i].balance();
        if (check_eligibility(bank._users[i])) nof_eligible++;
    }
    os << bank._bank_name << "\t" << nof_eligible << "\t" << balance<<std::endl;   
    return os;
}



