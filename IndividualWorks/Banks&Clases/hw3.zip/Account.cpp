#include "Account.h"
/**
    * Empty constructor
    * give the id as -1
    * give nullptr for pointers
    */
using namespace std;
void sort_transactions(Transaction* transactions, int size) {
    bool is_swapped = true;
    Transaction tmp;
    while (is_swapped)
    {
        is_swapped = false;
        for (size_t i = 0; i < size - 1; i++)
        {
            if (transactions[i] >    transactions[i + 1]) {
                tmp = transactions[i + 1];
                transactions[i + 1] = transactions[i];
                transactions[i] = tmp;
                is_swapped = true;
            }
        }
    }
}

Account::Account() {
    this->_id = -1;
    this->_activity = nullptr;
    this->_monthly_activity_frequency = nullptr;
}
/**
 * Constructor
 *
 *
 * Note: The given activity array will have 12 Transaction*
 * Each of these Transaction* will represent a month from the 2019
 * Basicaly activity[0] will represent January
 *          activity[11] will represent February
 *          activity[11] will represent March
 *                      ...
 *          activity[10] will represent November
 *          activity[11] will represent December
 * activity[0] will only contain Transactions happened in January
 * However, be careful that Transactions inside of activity[i] will not be in sorted order
 * For Example: We are certain that activity[0] is containing Transactions happened in January 2019
 * But we are not sure which of them happened first.
 * I strongly suggest you to use a sorting algorithm while storing these Transaction to your object.
 * (Sorting by the date, So that you can directly use them in stream overload)
 * (You can use bubble sort)
 *
 * @param id id of this Account
 * @param activity 2d Transaction array first layers lenght is 12 for each month
 * @param monthly_activity_frequency how many transactions made in each month
*/
Account::Account(int id, Transaction** const activity, int* monthly_activity_frequency) {
    _id = id;
    _monthly_activity_frequency = new int[12]{};
    _activity = new Transaction * [12]{};
    if (activity) {
        for (int i = 0; i < 12; i++) {
            _activity[i] = new Transaction[monthly_activity_frequency[i]];
            _monthly_activity_frequency[i] = monthly_activity_frequency[i];
            for (int j = 0; j < monthly_activity_frequency[i]; j++) {
                _activity[i][j] = activity[i][j];
            }
            sort_transactions(_activity[i], _monthly_activity_frequency[i]);
        }
    } 
}

/**
 * Destructor
 *
 * Do not forget to free the space you have created(This assignment does not use smart pointers)
 */
Account::~Account() {
    if (_activity != nullptr) {
        for (size_t i = 0; i < 12; i++)
        {
            delete[] _activity[i];
        }
        delete[] _activity;
    }
   if(_monthly_activity_frequency!=nullptr)  delete[] _monthly_activity_frequency;
}

/**
 * Copy constructor(Deep copy)
 *
 * @param other The Account to be copied
 */
Account::Account(const Account& rhs) {
    _id = rhs._id;
    _monthly_activity_frequency = new int[12]{};
    _activity = new Transaction * [12]{};
    if (rhs._activity) {
        for (int i = 0; i < 12; i++) {
            _activity[i] = new Transaction[rhs._monthly_activity_frequency[i]];
            _monthly_activity_frequency[i] = rhs._monthly_activity_frequency[i];
            for (int j = 0; j < rhs._monthly_activity_frequency[i]; j++) {
                _activity[i][j] = rhs._activity[i][j];
            }
        }
    }
   
}

/**
 * Copy constructor(Deep copy)
 *
 * This copy constructors takes two time_t elements
 * Transactions of the old Account will be copied to new Account
 * if and only if they are between these given dates
 * Given dates will not be included.
 *
 * @param rhs The Account to be copied
 * @param start_date Starting date for transaction to be copied.
 * @param end_date Ending date for transactions to be copied.
 */
Account::Account(const Account& rhs, time_t start_date, time_t end_date) {
    _id = rhs._id;
    _monthly_activity_frequency = new int[12]{};
    _activity = new Transaction * [12]{};
    if (rhs._activity) {
        for (int i = 0; i < 12; i++) {
            int start = 0, end = 0;
            for (int k = 0; k < rhs._monthly_activity_frequency[i]; k++) {
                if (!(rhs._activity[i][k] > start_date)) start++;
                end++;
                if (!(rhs._activity[i][k] < end_date)) break;
                //std::cout << "start:" << start << "end=" << end;
            }
            //std::cout << "start:" << start << "end" << end<<"\n";
            _activity[i] = new Transaction[end - start];
            _monthly_activity_frequency[i] = end - start;
            for (int j = start; j < end; j++) {
                _activity[i][j - start] = rhs._activity[i][j];
            }
        }
    }
   
}

/**
 * Move constructor
 *
 * @param rhs Account which you will move the resources from
 */
Account::Account(Account&& rhs) {
    this->_id = rhs._id;
    this->_activity = rhs._activity;
    this->_monthly_activity_frequency = rhs._monthly_activity_frequency;
    rhs._id = -1;
    rhs._activity = nullptr;
    rhs._monthly_activity_frequency = nullptr;
}
/**
 * Move assignment operator
 *
 * @param rhs Account which you will move the resources from
 * @return this account
 */
Account& Account::operator=(Account&& rhs) {
    if (this != &rhs) {
        if (_activity != nullptr) {
            for (size_t i = 0; i < 12; i++)
            {
              if(_activity[i]!=nullptr)  delete[] _activity[i];
            }
            delete[] _activity;
        }
        if (_monthly_activity_frequency != nullptr)  delete[] _monthly_activity_frequency;
        this->_id = rhs._id;
        this->_activity = rhs._activity;
        this->_monthly_activity_frequency = rhs._monthly_activity_frequency;
        rhs._activity = nullptr;
        rhs._monthly_activity_frequency = nullptr;
        rhs._id = -1;
    }
    return *this;
}

/**
 * Assignment operator
 * deep copy
 *
 * @param rhs Account to assign
 * @return this account
 */
Account& Account::operator=(const Account& rhs) {
    if (this != &rhs) {
        if (_activity != nullptr) {
            for (size_t i = 0; i < 12; i++)
            {
                delete[] _activity[i];
            }
            delete[] _activity;
        }
        if (_monthly_activity_frequency != nullptr)  delete[] _monthly_activity_frequency;
        _id = rhs._id;
        _activity = nullptr;
        _monthly_activity_frequency = nullptr;
        if (rhs._monthly_activity_frequency && rhs._activity) {
            _monthly_activity_frequency = new int[12];
            _activity = new Transaction * [12];
            if (rhs._activity) {
                for (int i = 0; i < 12; i++) {
                    _activity[i] = new Transaction[rhs._monthly_activity_frequency[i]];
                    _monthly_activity_frequency[i] = rhs._monthly_activity_frequency[i];
                    for (int j = 0; j < rhs._monthly_activity_frequency[i]; j++) {
                        _activity[i][j] = rhs._activity[i][j];
                    }
                }
            }
        }
           
    }   
 }
/**
 * Equality comparison overload
 *
 * This operator checks only id of the Account
 *
 * @param rhs The Account to compare
 * @return returns true if both ids are same false othervise
 */

bool Account:: operator==(const Account& rhs) const {
    return _id==rhs._id;
}
/**
 * Equality comparison overload
 *
 * This operator checks only id of the Account
 *
 * @param id to compare
 * @return returns true if both ids are same false othervise
 */
bool  Account:: operator==(int id) const {
    return _id==id;
}


/**
 * sum and equal operator
 * Add Transactions of two Accounts
 * You have to add transactions in correct places in your _activity array
 * Note: Remember that _activity[0] is always January and _activity[11] is always December
 * (This information also holds for every other month)
 *
 * You can have Transactions with the same date
 *
 * @param rhs Account which take new Transactions from
 * @return this Account after adding new Transactions
 */
Account& Account:: operator+=(const Account& rhs) {
    if (rhs._activity) {
        if (!_activity) {
            _activity = new Transaction * [12]{};
            _monthly_activity_frequency = new int[12]{ };
        }
        for (size_t i = 0; i < 12; i++)
        {           
            int total_t = 0, counter = 0;
            total_t = _monthly_activity_frequency [i]+ rhs._monthly_activity_frequency[i];
            Transaction* tmpd, * tmp = total_t ?new Transaction[total_t]:nullptr;
            for (int j = 0; j < _monthly_activity_frequency[i]; j++, counter++) {
                tmp[j] = _activity[i][j];
            }
            for (size_t k = 0; k < rhs._monthly_activity_frequency[i]; k++, counter++)
            {
                tmp[counter] = rhs._activity[i][k];
            }      
            if (_activity[i]) {
                delete [] _activity[i];               
            }            
            _activity[i] = tmp;
            
        }
    } 
    return *this;
}

/**
 * How much money Account has(Sum of Transaction amounts)
 *
 *
 * @return total amount of the money of the account
 */
double  Account::balance() {
    int total_amount = 0;
    if (!_activity) return 0;
    for (int i = 0; i < 12; i++)
    {
        for (int j = 0; j < _monthly_activity_frequency[i]; j++) {
            total_amount = _activity[i][j]+total_amount;
        }
    }
    return total_amount;
}

/**
 * How much money Account has at the end of given date
 *
 * Given date will not be included.
 * @param end_date You will count the amounts until this given date(not inclusive)
 * @return Total amount the Account has until given date
 */
double  Account::balance(time_t end_date) {
    if (!_activity) return 0;
    int total_amount = 0;
    for (int i = 0; i < 12; i++)
    {
        for (int j = 0; j < _monthly_activity_frequency[i]; j++) {
            if(_activity[i][j]<end_date) total_amount = _activity[i][j] + total_amount;
        }
    }
    return total_amount;
}


/**
 * How much money Account between given dates
 * Given dates will not be included.
 *
 * @param end_date You will count the amounts between given dates(not inclusive)
 * @return Total amount the Account has between given dates
 * You will only count a Transaction amount if and only if it occured between given dates
 */
double  Account::balance(time_t start_date, time_t end_date) {
    //cout << "balance from:" << gmtime(&start_date)->tm_mon<<"day="<< gmtime(&start_date)->tm_mday << "to" << gmtime(&end_date)->tm_mon<<"day=" << gmtime(&end_date)->tm_mday <<endl;
    int total_amount = 0;
    if (!_activity || !_monthly_activity_frequency) return 0;
    for (int i = 0; i < 12; i++)
    {
        
        for (int j = 0; j < _monthly_activity_frequency[i]; j++) {
           // cout << _activity[i][j];
            if (_activity[i][j] < end_date && _activity[i][j]>start_date) total_amount = _activity[i][j] + total_amount;
        }
       // cout << " month=" << i <<" total= "<<total_amount<< endl;
    }
    return total_amount;
}





/**
 * Stream overload.
 *
 *
 *
 * What to stream
 * Id of the user
 * Earliest Transaction amount"tab"-"tab"hour:minute:second-day/month/year(in localtime)
 * Second earliest Transaction amount"tab"-"tab"hour:minute:second-day/month/year(in localtime)
 * ...
 * Latest Transaction amount"tab-tab"hour:minute:second-day/month/year(in localtime)
 *
 * Note: _activity array will only contain dates from January 2019 to December 2019
 * Note: Transactions should be in order by date
 * Note: either of _monthly_activity_frequency or _activity is nullptr
 * you will just stream
 * -1
 * @param os Stream to be used.
 * @param Account to be streamed.
 * @return the current Stream
 */

std::ostream& operator<<(std::ostream& os, const Account& account) {
    if (account._activity == nullptr || account._monthly_activity_frequency == nullptr) return os << -1 << endl;
    os << account._id << endl;
    for (int i = 0; i < 12; i++)
    {
        for (int j = 0; j < account._monthly_activity_frequency[i]; j++) {
            os << account._activity[i][j];
        }
    }
    os << endl;
    return os;
}

